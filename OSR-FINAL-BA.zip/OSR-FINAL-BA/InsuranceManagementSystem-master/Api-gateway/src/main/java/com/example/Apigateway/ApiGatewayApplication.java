package com.example.Apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
		// - SpringApplication.run(): This static method starts the Spring application context.
        // - ApiGatewayApplication.class: You tell it which class is your main application class (the one with @SpringBootApplication).
        // - args: These are any command-line arguments you might pass to your application.
	}

}
