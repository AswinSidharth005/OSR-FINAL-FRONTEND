package com.cts.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.demo.dto.Policy;
import com.cts.demo.exception.ClaimNotFoundException;
import com.cts.demo.feignclient.PolicyClient;
import com.cts.demo.model.Claim;
import com.cts.demo.repository.ClaimRepository;
import com.cts.demo.service.ClaimServiceImpl;

class ClaimApplicationTests {

    @Mock
    private ClaimRepository repository;

    @Mock
    private PolicyClient policyClient;

    @InjectMocks
    private ClaimServiceImpl claimService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }









    @Test
    void testGetClaimById() throws ClaimNotFoundException {
        Claim claim = new Claim();

        when(repository.findById(1L)).thenReturn(Optional.of(claim));

        Claim result = claimService.getClaimById(1L);
        assertNotNull(result);
    }

    @Test
    void testGetAllClaims() {
        Claim claim1 = new Claim();
        Claim claim2 = new Claim();
        List<Claim> claims = Arrays.asList(claim1, claim2);

        when(repository.findAll()).thenReturn(claims);

        List<Claim> result = claimService.getAllClaims();
        assertEquals(2, result.size());
    }

 
}
