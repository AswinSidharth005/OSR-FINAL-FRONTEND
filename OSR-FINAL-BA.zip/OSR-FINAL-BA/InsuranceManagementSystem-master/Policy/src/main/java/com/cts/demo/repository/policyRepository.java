package com.cts.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.demo.project.Policy;


public interface policyRepository extends JpaRepository<Policy, Long> {
	


}
