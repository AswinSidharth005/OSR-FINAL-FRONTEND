package com.cts.demo.exception;

public class PolicyNotFoundException extends Exception {


	public PolicyNotFoundException(String message) {
		super(message);
	}
}
