package com.cts.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.demo.dto.Agent;
import com.cts.demo.dto.Customer;
import com.cts.demo.exception.PolicyNotFoundException;
import com.cts.demo.feignclient.AgentClient;
import com.cts.demo.feignclient.CustomerClient;
import com.cts.demo.project.Policy;
import com.cts.demo.repository.policyRepository;
import com.cts.demo.service.policyServiceImpl;

class PolicyApplicationTests {

    @Mock
    private policyRepository repository;

    @Mock
    private CustomerClient customerClient;

    @Mock
    private AgentClient agentClient;

    @InjectMocks
    private policyServiceImpl policyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }



    @Test
    void testUpdatePolicy() {
        Policy policy = new Policy();
        when(repository.save(policy)).thenReturn(policy);

        Policy result = policyService.updatePolicy(policy);
        assertEquals(policy, result);
    }

    @Test
    void testRetrievePolicy() throws PolicyNotFoundException {
        Policy policy = new Policy();
        when(repository.findById(1L)).thenReturn(Optional.of(policy));

        Policy result = policyService.retrievePolicy(1L);
        assertNotNull(result);
    }


    @Test
    void testRetrieveAll() throws PolicyNotFoundException {
        Policy policy1 = new Policy();
        Policy policy2 = new Policy();
        List<Policy> policies = Arrays.asList(policy1, policy2);

        when(repository.findAll()).thenReturn(policies);

        List<Policy> result = policyService.retrieveAll();
        assertEquals(2, result.size());
    }

    @Test
    void testAssignPolicyToCustomer() throws PolicyNotFoundException {
        Customer customer = new Customer();
        when(repository.existsById(1L)).thenReturn(true);
        when(customerClient.assignPoliciesToCustomer(1L, 1L, "type")).thenReturn(customer);

        Customer result = policyService.assignPolicyToCustomer(1L, 1L, "type");
        assertNotNull(result);
    }

    @Test
    void testAssignPolicyToAgent() throws PolicyNotFoundException {
        Agent agent = new Agent();
        when(repository.existsById(1L)).thenReturn(true);
        when(agentClient.assignPoliciesToAgent(1L, 1L, "type")).thenReturn(agent);

        Agent result = policyService.assignPolicyToAgent(1L, 1L, "type");
        assertNotNull(result);
    }
}