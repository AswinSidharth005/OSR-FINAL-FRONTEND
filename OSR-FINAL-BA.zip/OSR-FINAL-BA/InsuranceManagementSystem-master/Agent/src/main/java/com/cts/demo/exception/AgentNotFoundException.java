package com.cts.demo.exception;

public class AgentNotFoundException extends Exception {
	public AgentNotFoundException(String message) {
		super(message);
	}

}
